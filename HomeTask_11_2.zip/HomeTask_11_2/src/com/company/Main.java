package com.company;

public class Main {

    public static void main(String[] args) {

//        String scanner = "Запускаем ошибка завершен";
//        System.out.println("Вы ввели: " + scanner);
//
//        if (scanner.startsWith("Запуск"))
//            System.out.println("Запускаем процесс");
//
//        if (scanner.endsWith("завершен"))
//            System.out.println("Процесс завершен");
//
//        if (scanner.compareToIgnoreCase("ошибка")==0)
//            System.out.println("Произошла ошибка");
    }
}